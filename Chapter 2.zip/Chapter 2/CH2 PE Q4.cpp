#include <stdio.h>
int main() {
	printf("I am a boy\nI Live in Pakistan\nI am a proud Pakistani");
	return 0;
}
