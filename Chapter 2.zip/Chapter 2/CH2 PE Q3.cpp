#include <stdio.h>
int main() {
	printf("*\t*\t*\t*\n1\t2\t3\t4");
	return 0;
}
